# Orgapi – Beschreibung für den App-Store

Alle Texte sind auf Deutsch (Schweiz, mit «ss»). Die Längen stehen bei jedem Feld. **Google Play** ist der Hauptfall, weil die App als PWA über PWABuilder dorthin kommt. Am Ende stehen die Felder für den Apple App Store.

## Google Play

### App-Name (max. 30 Zeichen)
Vorschlag: **Orgapi: Haushalt & Familie** (26 Zeichen). «Orgapi: Haushalt & Familienplaner» hat 33 Zeichen und passt nicht, darum steht «Haushalt- & Familienplaner» am Anfang der Kurzbeschreibung.
Alternative: Orgapi Familienplaner (21 Zeichen)

### Kurzbeschreibung (max. 80 Zeichen)
Haushalt- & Familienplaner: Kalender, Putzen, Einkaufen, Essen und Aufgaben.
(76 Zeichen)

### Vollständige Beschreibung (max. 4000 Zeichen)
(2663 Zeichen. Die Symbole am Zeilenanfang kannst du löschen, falls sie in der Vorschau stören.)

Orgapi ist dein Haushalt- und Familienplaner: Termine, Putzplan, Einkaufsliste, Essensplan und Aufgaben an einem Ort. Ohne Anmeldung, ohne Werbung, kostenlos. Deine Daten bleiben auf deinem Gerät.

🏠 STARTSEITE «HEUTE»
Alles, was heute ansteht, auf einen Blick: Termine, Putzen, Einkaufen, Essen und Aufgaben. Mit einem Tipp einen Tag vor oder zurück, oder im Kalender ein beliebiges Datum wählen. Mit dem Filter blendest du Bereiche aus.

📅 KALENDER
• Tag, Woche oder Zeitraster mit Uhrzeiten
• Termine pro Person, mit Wiederholung
• Wochenvorlage speichern und laden
• Termine in deine Kalender-App übernehmen

🧹 PUTZEN
• Übersichtliche Tabelle: Was, wie oft, an welchem Tag, wer
• Zyklen wie 1× pro Woche oder 2× pro Monat
• Erledigtes abhaken, offene Aufgaben sind sofort sichtbar

🧺 EINKAUFEN
• Liste nach Kategorien in Ladenreihenfolge oder von Hand sortiert
• Artikeln Läden zuordnen (Migros, Coop, Lidl, Aldi und eigene)
• Preise, Aktionen und der günstigste Laden
• Produkt per Strichcode oder Foto erfassen: Name, Menge, Marke, Laden, Kategorie und Preis werden, wenn möglich, automatisch vorausgefüllt
• Saisonkalender für die Schweiz
• Standardliste mit Artikeln, die jede Woche gebraucht werden (auf Wunsch automatisch)
• Einkaufsliste als Link teilen

🍽 ESSEN
• Frühstück, Mittag und Abend für die ganze Woche planen
• Eigene Rezepte speichern, auch aus kopiertem Text einfügen
• Zufallsplan mit Vorschlägen
• Zutaten mit einem Tipp auf die Einkaufsliste

✅ AUFGABEN
• Tabelle mit Tag, Zyklus und Person
• Wichtiges markieren, Wiederkehrendes springt beim Abhaken zum nächsten Termin

⚙️ NOCH MEHR
• Eigene Seiten und frei anpassbare Leiste unten
• Suche über alles
• Kalenderabgleich mit dem Handy über Kalenderdateien (.ics), Import mit Vorschau
• Familien-Paket: Namen, Putzplan und Standardliste per QR-Code, Link oder Datei an die Familie weitergeben
• Teilen, Drucken (A4-Wochenübersicht) und Export als CSV
• Sicherung als Datei, dazu automatische Sicherungen auf dem Gerät

♿ FÜR ALLE GUT LESBAR
Grosse Bedienelemente, hoher Kontrast, Hell- und Dunkelmodus. Die App passt sich der Schriftgrösse deines Geräts an.

🔒 DATENSCHUTZ
Keine Anmeldung, kein Konto, keine Werbung. Alle Einträge bleiben auf deinem Gerät. Nur wenn du Produkte scannst, wird die Strichcode-Nummer bei der offenen Datenbank Open Food Facts abgefragt, und die Texterkennung wird einmalig geladen. Die Kamera wird nur dafür gebraucht und nur, wenn du sie erlaubst.

GUT ZU WISSEN
• Die Daten werden nicht automatisch zwischen Geräten abgeglichen. Mit der Sicherungsdatei kannst du sie auf ein anderes Gerät übertragen.
• Orgapi sendet selbst keine Benachrichtigungen. Für Erinnerungen übernimmst du Termine in deine Kalender-App.
• Die App funktioniert auch ohne Internet. Nur die Produkt-Suche und die Texterkennung brauchen es.

Orgapi ist für Familien, Paare und WGs gemacht, die Haushalt und Alltag einfach und übersichtlich organisieren wollen.

### Was ist neu (max. 500 Zeichen)
(375 Zeichen)

• Handy-Kalender abgleichen: Termine als Kalenderdatei exportieren und aus Kalenderdateien übernehmen (mit Vorschau)
• Familien-Paket: Namen, Putzplan und Standardliste per QR-Code, Link oder Datei weitergeben
• Standardliste für Artikel, die jede Woche gebraucht werden
• Hinweis, wenn Speichern nicht klappt, und bei neuer App-Version
• Karte «Erste Schritte» für den Start

### Kategorie und Einstellungen
- Kategorie: **Produktivität** (alternativ «Lifestyle»)
- Sprache: Deutsch (Schweiz) bzw. Deutsch
- Preis: kostenlos, keine Werbung, keine In-App-Käufe
- Kontakt-E-Mail: [Kontakt-E-Mail eintragen]
- Datenschutzerklärung (Web-Adresse): [Adresse von datenschutz.html eintragen, z. B. https://DEINNAME.github.io/orgapi/datenschutz.html]
- Berechtigung: Kamera (nur für den optionalen Produkt-Scan)

### Grafiken
- App-Symbol 512 × 512: `icon-512.png`
- Screenshots Hochformat (1080 × 2400): `screenshots/screenshot-0-start.png` bis `screenshot-5-aufgaben.png`
- Screenshot breit (1280 × 800), für Tablets: `screenshots/screenshot-wide-overview.png`
- Feature-Grafik 1024 × 500 (Pflicht bei Google Play): `feature-grafik-1024x500.png` (PNG ohne Transparenz)

### Hilfe zu den Fragebögen in der Play Console
Das sind meine Einschätzungen, keine Rechtsberatung. Bitte beim Ausfüllen selbst gegen die Angaben in der Console prüfen.
- **Altersfreigabe:** Die App hat keine Gewalt, keine Nutzerkommunikation, keine Käufe, keine Werbung. Das führt voraussichtlich zur niedrigsten Stufe.
- **Datensicherheit:** Der Entwickler erhält keine Daten, es gibt kein Konto und kein Tracking. Dienste von Dritten, die die App nur bei Gebrauch anspricht: Open Food Facts (Strichcode-Nummer, nur beim Scannen), jsDelivr (lädt einmalig die Texterkennung), Websites der Läden (öffnen sich im Browser). Prüfe, ob Google die Abfrage bei Open Food Facts bei dir als «Weitergabe» zählt, und passe die Antwort an. Die Datenschutzseite beschreibt das alles.
- **Verschlüsselung:** Die Daten liegen unverschlüsselt im lokalen Speicher des Geräts. Verbindungen ins Internet laufen über HTTPS.

## Apple App Store (falls du dort auch veröffentlichst)
- Name (max. 30): Orgapi: Haushalt & Familie
- Untertitel (max. 30): Familie, Haushalt, Einkauf (26 Zeichen)
- Werbetext (max. 170): Termine, Putzplan, Einkaufsliste, Essensplan und Aufgaben an einem Ort. Ohne Konto, ohne Werbung. (97 Zeichen)
- Schlüsselwörter (max. 100, mit Komma, ohne Leerzeichen): familienplaner,putzplan,einkaufsliste,wochenplan,essensplan,haushalt,aufgaben,kalender,schweiz (94 Zeichen)
- Beschreibung: wie die Vollbeschreibung oben
- Hinweis: Apple verlangt bei reinen Web-Apps oft zusätzlichen Nutzen gegenüber einer Webseite. Das lässt sich nur im Prüfprozess herausfinden.
