const CACHE = 'orgapi-v76';
const ASSETS = ['./', './index.html', './orgapi.html', './datenschutz.html', './manifest.json', './icon-192.png', './icon-512.png', './fonts/inter-var-latin.woff', './fonts/space-grotesk-var-latin.woff', './logos/migros.png', './logos/coop.svg', './logos/lidl.png', './logos/aldi.png', './vendor/qrcodegen.js'];
// Die PDF-Dateien (vendor/) werden nicht vorab geladen: Sie kommen erst beim ersten PDF-Import in den Zwischenspeicher (siehe fetch unten).

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
  );
  self.clients.claim();
});

// Seiten: zuerst Netz (damit Updates ankommen), sonst Cache. Übrige Dateien: zuerst Cache.
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== self.location.origin) return;
  const isPage = e.request.mode === 'navigate' || url.pathname.endsWith('.html') || url.pathname.endsWith('/');
  if (isPage) {
    e.respondWith(
      fetch(e.request).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, copy));
        return res;
      }).catch(() => caches.match(e.request).then((m) => m || caches.match('./orgapi.html')))
    );
    return;
  }
  e.respondWith(
    caches.match(e.request).then((cached) => cached || fetch(e.request).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(e.request, copy));
      return res;
    }))
  );
});
