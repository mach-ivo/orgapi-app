# Anleitung: Node.js, Android Studio und die Orgapi-App auf dem Handy

Für Einsteiger, in der Reihenfolge, in der du es tust. Plane beim ersten Mal 1–2 Stunden ein, der grösste Teil davon ist Warten auf Downloads. Alle Zeit- und Grössenangaben sind grobe Schätzungen.

**Ehrlich vorab:** Ich konnte diese Schritte nicht selbst auf einem Computer mit Android Studio ausführen. Die Anleitung beruht auf dem üblichen Ablauf. Menünamen können sich je nach Version leicht unterscheiden. Wenn etwas anders aussieht oder eine Meldung erscheint, schick mir den Wortlaut oder einen Screenshot.

---

## 0. Wer fragt wen? (Kalender-Berechtigung)

Die Berechtigung geht **von der App aus**. So läuft es:

1. Du tippst in Orgapi auf «Zugriff erlauben».
2. **Orgapi bittet Android** um den Zugriff auf den Kalender.
3. **Android fragt dich** in einem Fenster: «Orgapi erlauben, auf Kalender zuzugreifen?»
4. Du tippst «Zulassen». Erst jetzt darf Orgapi Termine im Handy-Kalender lesen und schreiben.

Der umgekehrte Weg (die Kalender-App schiebt von sich aus Termine in Orgapi) gibt es nicht. Orgapi holt Termine nur, wenn du «Aus Handy-Kalender holen» tippst, und schreibt nur, wenn du «In Handy-Kalender schreiben» tippst. Die Berechtigung kannst du jederzeit entziehen: Android-Einstellungen → Apps → Orgapi → Berechtigungen → Kalender.

---

## 1. Node.js installieren

Node.js ist das Programm, mit dem das Skript `prepare.mjs` läuft.

1. Gehe auf **nodejs.org** und lade die Version mit **LTS** herunter (nicht «Current»). Nimm eine aktuelle LTS-Version, mindestens Version 22.
2. Starte die heruntergeladene Datei und klicke durch den Installer (alle Voreinstellungen lassen).
3. **Terminal öffnen:**
   - **Windows:** Taste Windows drücken, «cmd» eintippen, **Eingabeaufforderung** öffnen. Nimm bewusst nicht «PowerShell»: Dort blockiert Windows manchmal den Befehl `npx` mit der Meldung «Die Datei … npx.ps1 kann nicht geladen werden».
   - **Mac:** Programme → Dienstprogramme → **Terminal**.
4. Prüfen:
   ```
   node --version
   ```
   Es erscheint eine Zahl wie `v22.x.x` (oder höher). Erscheint «nicht gefunden», das Terminal schliessen und neu öffnen. Hilft das nicht, den Computer neu starten.

---

## 2. Android Studio installieren

1. Gehe auf **developer.android.com/studio** und lade Android Studio herunter.
2. Installieren (Voreinstellungen lassen). Platz: rechne mit rund 10 GB freiem Speicher, besser mehr.
3. Beim **ersten Start** erscheint ein Einrichtungsassistent:
   - «Standard» (Standard-Installation) wählen.
   - Die Lizenzen annehmen («Accept»).
   - Warten, bis die Komponenten (u. a. das Android SDK) heruntergeladen sind. Das kann 10–30 Minuten dauern.
4. Java musst du **nicht** separat installieren, Android Studio bringt es mit.

---

## 3. Projekt vorbereiten

1. Entpacke `orgapi-android-projekt.zip` an einen **einfachen Ort ohne Leerzeichen**, z. B. `C:\orgapi-android` (Windows) oder in deinen Benutzerordner (Mac). Vermeide OneDrive- oder Cloud-Ordner und sehr lange Pfade.
2. Terminal **in diesem Ordner** öffnen:
   - **Windows:** Im Explorer den Ordner `orgapi-android` öffnen, oben in die Adresszeile klicken, `cmd` eintippen, Enter.
   - **Mac:** Im Terminal `cd ` (mit Leerzeichen) tippen, den Ordner `orgapi-android` ins Terminal ziehen, Enter.
3. Ausführen:
   ```
   node prepare.mjs
   ```
   Das lädt Bausteine aus dem Internet (einige Minuten) und schreibt am Ende «Fertig. Nächster Schritt: npx cap open android». Rote Zeilen mit «npm WARN» sind meist harmlos. Bei «ERROR» oder «FEHLER»: die Meldung kopieren und schicken.
4. Das Skript nimmt die Voreinstellungen (App-ID `io.github.raster_werk.orgapi`, Adresse `https://raster-werk.github.io/orgapi/orgapi.html`). Die Adresse muss erst online sein, damit Links und QR-Codes später funktionieren. Die App selbst läuft auch ohne.

---

## 4. In Android Studio öffnen

1. Im selben Terminal:
   ```
   npx cap open android
   ```
   Android Studio startet mit dem Projekt. Klappt das nicht: Android Studio selbst starten → **Open** → den Ordner `orgapi-android/android` wählen.
2. Beim ersten Öffnen läuft unten rechts ein Balken **«Gradle Sync»** / «Gradle build running». **Warten**, bis er verschwindet (beim ersten Mal 5–15 Minuten, braucht Internet).
3. Schlägt Android Studio ein **Update** vor («Update Android Gradle Plugin» o. ä.), **nicht annehmen**, sondern «Remind me later» bzw. schliessen. Das Projekt ist auf bestimmte Versionen eingestellt.

---

## 5. Handy vorbereiten

1. **Entwickleroptionen freischalten:** Einstellungen → «Über das Telefon» (bzw. «Telefoninfo») → **Build-Nummer** 7× schnell antippen. Es erscheint «Du bist jetzt Entwickler». (Bei manchen Marken steht die Build-Nummer unter «Softwareinformationen».)
2. Einstellungen → **Entwickleroptionen** → **USB-Debugging** einschalten.
3. Handy per **USB-Kabel** mit dem Computer verbinden (ein Datenkabel, nicht nur ein Ladekabel). Am Handy bei «USB-Debugging zulassen?» auf **Zulassen** tippen (Häkchen «immer» ist praktisch).
4. In Android Studio oben in der Leiste erscheint dein Handy in der Geräteauswahl. Erscheint es nicht: Kabel wechseln, am Handy als USB-Modus «Dateiübertragung» wählen, bei Windows evtl. den Treiber des Herstellers (z. B. Samsung) installieren.

*Alternative ohne Handy:* Im Android Studio **Device Manager** (Handy-Symbol rechts) → «Create Device» einen virtuellen Handy-Emulator anlegen. Für den Kalender-Abgleich ist ein echtes Handy aber aussagekräftiger.

---

## 6. App starten und Kalender prüfen

1. In Android Studio oben das Handy wählen und auf den **grünen Pfeil (Run)** drücken. Die App wird installiert und startet (beim ersten Mal 1–3 Minuten).
2. In Orgapi: ⋮ → **«Handy-Kalender abgleichen …»**.
3. Es sollte der Abschnitt **«Direkt mit dem Handy-Kalender»** erscheinen. Tippe **«Zugriff erlauben»**: Android fragt nach dem Kalender, tippe «Zulassen».
4. Wähle den Handy-Kalender, trage in Orgapi einen Test-Termin ein und tippe **«In Handy-Kalender schreiben»**. Prüfe in der Kalender-App, ob der Termin da ist.
5. Prüfliste: `PRUEFLISTE.md`, Zeilen 76 und 77.

**Fehlt der Abschnitt «Direkt mit dem Handy-Kalender»?** Dann wird das Kalender-Baustein nicht gefunden. Im Terminal im Projektordner eingeben: `npm ls @ebarooni/capacitor-calendar` und die Ausgabe schicken.

**Fragt Android nie nach dem Kalender?** Einstellungen → Apps → Orgapi → Berechtigungen → Kalender → Zulassen.

---

## 7. Häufige Probleme

| Meldung / Problem | Was du tust |
|---|---|
| `'node' wird nicht erkannt` | Terminal schliessen und neu öffnen, sonst Computer neu starten. |
| PowerShell: «npx.ps1 kann nicht geladen werden» | Stattdessen die **Eingabeaufforderung (cmd)** verwenden. |
| `ENOTFOUND` / `network` bei `node prepare.mjs` | Keine Internetverbindung oder Firmen-/Schulnetz mit Sperre. Anderes Netz versuchen. |
| Gradle Sync schlägt fehl, «SDK location not found» | In Android Studio: Tools → SDK Manager → «Android SDK Location» prüfen und das SDK installieren lassen. |
| «Unsupported class file major version» o. ä. | Settings → Build, Execution, Deployment → Build Tools → Gradle → **Gradle JDK**: die mitgelieferte Version («jbr» bzw. «Embedded JDK») wählen. |
| Handy erscheint nicht in der Geräteliste | Anderes Kabel, USB-Modus «Dateiübertragung», USB-Debugging am Handy neu bestätigen. |
| App startet, bleibt weiss | Im Terminal des Projektordners `node prepare.mjs` erneut ausführen, in Android Studio erneut «Run». Bleibt es weiss: Screenshot schicken. |
| Sonst | Meldung im Wortlaut kopieren und mir schicken. |

---

## 8. Danach: für den Play Store

Siehe `LIESMICH.md` (Abschnitt «Für den Play Store»): signiertes Bundle bauen, Schlüssel sicher aufbewahren, im Play Console hochladen. Vor jeder neuen Version `versionCode` erhöhen.
