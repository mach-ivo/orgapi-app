# Orgapi Android-App: Schritt für Schritt

**Neu im Einsteiger-Stil:** Zur Installation von Node.js und Android Studio und zum Start auf dem Handy siehe `ANLEITUNG-NODE-ANDROID-STUDIO.md`.
**Für Linux Mint:** siehe `ANLEITUNG-LINUX-MINT.md`.

Dieser Ordner baut aus Orgapi eine Android-App (mit Capacitor), die direkt mit dem Handy-Kalender abgleichen kann. Hintergrund und offene Punkte stehen in `ANDROID-APP.md`.

**Ehrlich vorab:** Das Skript habe ich hier nur im Probelauf getestet (Dateien kopieren, Adresse und Berechtigungen eintragen). Der eigentliche Bau mit Android Studio und die App auf einem Handy sind ungeprüft. Gehe langsam vor und schicke mir jede Fehlermeldung im Wortlaut.

## Einmalig vorbereiten
1. **Node.js** installieren (aktuelle LTS-Version von nodejs.org). Prüfen im Terminal: `node --version`.
2. **Android Studio** installieren (developer.android.com/studio). Beim ersten Start die vorgeschlagenen Komponenten (Android SDK) installieren lassen.
3. **Voreingestellt für dich** (in `prepare.mjs` oben, falls du etwas ändern willst):
   - App-ID: `io.github.raster_werk.orgapi`. Sie ist für immer fest, sobald die App im Play Store ist. Ändere sie also vorher, falls du eine andere willst.
   - Adresse: `https://raster-werk.github.io/orgapi/orgapi.html` (für Links und QR-Codes des Familien-Pakets).
4. **Orgapi muss unter dieser Adresse online stehen** (GitHub Pages, Anleitung in `HOSTING.md`, Weg B): GitHub-Name bzw. Organisation `raster-werk`, öffentliches Repository `orgapi`, Inhalt des Ordners `orgapi-pwa` hochladen, Pages einschalten. Vorher in `datenschutz.html` den Platzhalter `[Kontakt-E-Mail eintragen]` ersetzen.

## App erzeugen
Im Terminal in diesen Ordner wechseln (`cd orgapi-android`) und ausführen:

```
node prepare.mjs
```

(Mit anderen Werten: `node prepare.mjs --id DEINE.APP.ID --url https://DEINE-ADRESSE/orgapi.html`. Mit `--url ""` ganz ohne Adresse.)

Das Skript installiert die Bausteine, kopiert die Web-Dateien, trägt die Adresse ein, legt das Android-Projekt an, ergänzt die Berechtigungen (Kalender, Kamera) und gleicht alles ab. Das dauert beim ersten Mal einige Minuten. Danach:

```
npx cap open android
```

Das öffnet Android Studio. Warten, bis unten die «Gradle»-Synchronisierung fertig ist.

## Auf dem Handy ausprobieren
1. Handy: Entwickleroptionen und «USB-Debugging» einschalten, per Kabel verbinden.
2. In Android Studio oben das Handy wählen und auf den grünen Pfeil (Run) tippen.
3. Prüfen, was in `PRUEFLISTE.md` unter 76 und 77 steht: Kalender-Abgleich, Teilen-Menü für Dateien, Kamera.
4. Zusätzlich beachten: Funktioniert die **Zurück-Taste** sinnvoll (schliesst ein offenes Fenster, statt die App zu beenden)? Liegt der Inhalt auf neueren Android-Versionen **unter der Statusleiste oder der unteren Navigationsleiste**? Beides habe ich nicht prüfen können, bitte melde es mir, wenn es auffällt.

## App-Symbol
In Android Studio: Rechtsklick auf `app` → New → Image Asset → «Launcher Icons», als Quelle `web/icon-512.png` wählen, Fertig. (Das Symbol sollte auf dem Handy nicht abgeschnitten wirken, sonst im Assistenten die Skalierung verkleinern.)

## Für den Play Store
1. In Android Studio: Build → **Generate Signed App Bundle** → Android App Bundle. Neuen Schlüssel anlegen und **Schlüsseldatei samt Passwörtern sicher aufbewahren** (ohne sie sind spätere Updates nicht möglich).
2. In `android/app/build.gradle` stehen `versionCode` (bei jedem Update um 1 erhöhen) und `versionName`.
3. Play Console: App anlegen, die `.aab`-Datei hochladen, Texte und Grafiken aus `STORE-BESCHREIBUNG.md`, Datenschutz-Adresse `https://raster-werk.github.io/orgapi/datenschutz.html` (die Seite muss online stehen), Formular «Datensicherheit»: Orgapi sendet keine Daten an Server, Kalenderdaten werden nur auf dem Gerät verarbeitet.
4. Neue private Entwicklerkonten brauchen vor der Veröffentlichung einen geschlossenen Test (zuletzt: mindestens 12 Tester über 14 Tage, bitte im Play Console prüfen).

## Nach jeder Änderung an Orgapi
1. Neue Web-Dateien in den Ordner `web/` kopieren (alte überschreiben).
2. `node prepare.mjs` erneut ausführen (geht jetzt schnell).
3. In Android Studio `versionCode` erhöhen, neues Bundle bauen, hochladen.

## Wenn etwas nicht klappt
- «Abschnitt Direkt mit dem Handy-Kalender fehlt»: Das Kalender-Plugin wird nicht gefunden. Im Terminal `npm ls @ebarooni/capacitor-calendar` ausführen und mir die Ausgabe schicken.
- Fehler beim Gradle-Sync: Meldung kopieren und schicken.
- Neustart des Skripts ist gefahrlos, es kann beliebig oft laufen.
