# Orgapi als echte Android-App (mit direktem Kalender-Zugriff)

**Wichtig vorab:** Diese Anleitung ist ungetestet auf einem echten Gerät. Ich konnte hier keine App-Datei bauen (kein Android-SDK, Paketquelle gesperrt). Orgapi selbst ist vorbereitet und in einer Nachbildung der Plugins getestet, die echte App musst du auf deinem Handy prüfen.

## Wann lohnt sich das?
- **Ja**, wenn Orgapi direkt in den Handy-Kalender schreiben und daraus lesen soll (mit der Android-Berechtigung «Kalender»).
- **Nein**, wenn Dateien (.ics) und das Teilen-Menü reichen. Dann bleibt die einfache PWABuilder-Variante (Trusted Web Activity) besser: Updates kommen sofort, es gibt nichts zu bauen.

## Was anders ist als bei der PWA-Variante
- Du baust bei **jeder Änderung** eine neue App-Datei (AAB) und lädst sie im Play Console hoch. Updates kommen nicht mehr einfach durch Hochladen auf den Webspace.
- Die Daten der App liegen im WebView der App, **nicht** im Chrome der PWA. Wer von der PWA wechselt, nimmt seine Daten über «Sicherung als Datei» mit.
- Der Service-Worker und der Update-Hinweis sind in der App abgeschaltet (Orgapi erkennt das selbst).
- Links und QR-Codes (Familien-Paket, Einkaufsliste) brauchen eine öffentliche https-Adresse. In der App steht sonst «localhost». Trage deine Adresse in `orgapi.html` bei `const PUBLIC_URL = '';` ein, z. B. `'https://deinname.github.io/orgapi/orgapi.html'`. Die Datei-Wege gehen immer.

## Was du brauchst
- Computer mit **Node.js** (aktuelle LTS-Version) und **Android Studio** (mit Android SDK).
- Ein Google-Play-Entwicklerkonto, um zu veröffentlichen. Neue private Konten müssen vor der Veröffentlichung einen geschlossenen Test mit mindestens 12 Testern über 14 Tage durchführen (Stand meiner Recherche, bitte im Play Console prüfen).

## Schritte
**Kurzfassung:** Im Ordner `orgapi-android` (Datei `LIESMICH.md`) erledigt das Skript `prepare.mjs` die Schritte 1–4 und 8 automatisch. Die Einzelschritte unten sind nur zum Nachvollziehen.

1. Neuen Ordner anlegen, z. B. `orgapi-app`, und darin im Terminal:
   ```
   npm init -y
   npm i @capacitor/core @capacitor/android @capacitor/filesystem @capacitor/share @ebarooni/capacitor-calendar
   npm i -D @capacitor/cli
   npx cap init Orgapi ch.deinname.orgapi --web-dir www
   ```
   Die App-ID (`ch.deinname.orgapi`) muss weltweit eindeutig sein und lässt sich später nicht mehr ändern.
2. Ordner `www` anlegen und den **Inhalt** des PWA-Ordners (`orgapi-pwa`) hineinkopieren (orgapi.html, index.html, fonts, logos, vendor, …). `index.html` leitet auf `orgapi.html` weiter, das passt so.
3. Android-Projekt erzeugen:
   ```
   npx cap add android
   npx cap sync android
   ```
4. Berechtigungen eintragen: In `android/app/src/main/AndroidManifest.xml` innerhalb von `<manifest>` (nicht in `<application>`) ergänzen:
   ```
   <uses-permission android:name="android.permission.READ_CALENDAR" />
   <uses-permission android:name="android.permission.WRITE_CALENDAR" />
   <uses-permission android:name="android.permission.CAMERA" />
   <uses-feature android:name="android.hardware.camera" android:required="false" />
   ```
   (Die Kamera brauchst du nur für Strichcode und Foto-Scan.)
5. Öffnen und testen: `npx cap open android` startet Android Studio. Auf dem Handy oder einem Emulator ausführen.
6. Für den Store: In Android Studio «Build → Generate Signed App Bundle» (AAB), Schlüssel gut aufbewahren. Version bei jedem Update erhöhen (`versionCode` in `android/app/build.gradle`).
7. Play Console: Datenschutzerklärung-Link, Formular «Datensicherheit» (Orgapi sendet nichts an Server; Kalenderdaten werden nur auf dem Gerät verarbeitet), Inhaltseinstufung.
8. Nach jeder Änderung an den Web-Dateien: Dateien nach `www` kopieren und `npx cap sync android`.

## So prüfst du die App auf dem Handy
- Menü ⋮ → «Handy-Kalender abgleichen …»: Es erscheint der Abschnitt «Direkt mit dem Handy-Kalender». «Zugriff erlauben» zeigt die Android-Abfrage.
- «In Handy-Kalender schreiben»: Einträge erscheinen im gewählten Kalender, ein zweiter Durchgang legt nichts doppelt an, Änderungen und Löschungen in Orgapi werden nachgezogen. Fremde Einträge bleiben unberührt.
- «Aus Handy-Kalender holen»: Vorschau der nächsten 8 Wochen (Mo–Fr, mit Uhrzeit). Übernommene Termine werden nie zurück in den Kalender geschrieben (sonst doppelt).
- Sicherung, Kalenderdatei und Familien-Paket als Datei: Es öffnet sich das Teilen-Menü von Android.

## Offene Punkte (bitte auf dem Gerät beachten)
- **Plugin-Name:** Orgapi spricht das Plugin als `Capacitor.Plugins.CapacitorCalendar` an. Fehlt der Abschnitt «Direkt mit dem Handy-Kalender», ist der Name oder die Installation das Erste, was zu prüfen ist.
- **Wiederkehrende Termine:** Ich konnte nicht belegen, ob das Plugin unter Android jeden einzelnen Termin einer Serie liefert oder nur den ersten. Bitte mit einer Serie testen.
- **Am Handy gelöschte Einträge:** Löschst du einen von Orgapi angelegten Eintrag im Handy-Kalender, legt Orgapi ihn erst wieder an, wenn du ihn in Orgapi änderst.
- **Drucken (A4-Wochenübersicht):** Das Druckfenster des Browsers fehlt im WebView. Orgapi bietet dann die Datei zum Teilen an; von dort lässt sie sich öffnen und drucken.
- **Kamera:** Im WebView hängt der Zugriff von der Android-Berechtigung ab. Bitte Strichcode und Foto-Scan testen.
- **iPhone:** Eine iOS-App braucht zusätzlich einen Mac, Xcode und ein Apple-Entwicklerkonto (99 USD pro Jahr), und die Kalender-Texte (`NSCalendars…UsageDescription`) in `Info.plist`.
