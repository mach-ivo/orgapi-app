# Anleitung für Linux Mint: Node.js, Android Studio und die Orgapi-App auf dem Handy

Diese Fassung ist für **Linux Mint**. Die Schritte 0 (Kalender-Berechtigung), 6 und 7 der allgemeinen Anleitung (`ANLEITUNG-NODE-ANDROID-STUDIO.md`) gelten unverändert. Hier stehen nur die Linux-Schritte.

**Ehrlich vorab:** Ich konnte das nicht selbst auf einem Linux-Mint-Rechner mit Android Studio ausführen. Die Befehle sind die üblichen für Mint/Ubuntu. Menünamen und Dateinamen können je nach Version leicht abweichen. Wenn eine Meldung erscheint, kopiere sie im Wortlaut und schick sie mir.

Plane beim ersten Mal 1–2 Stunden ein, das meiste davon ist Warten auf Downloads. Freier Speicher: rund 10 GB oder mehr. Arbeitsspeicher: 8 GB sind angenehm.

**Terminal öffnen:** Taste **Strg + Alt + T**. Oder: Im Dateimanager in den gewünschten Ordner gehen, Rechtsklick auf eine leere Stelle → **«Im Terminal öffnen»**.

---

## 1. Node.js installieren

Das Programm aus der Mint-Paketquelle ist oft zu alt. Nimm deshalb die Quelle von NodeSource (eine bekannte Paketquelle für Node.js):

```
sudo apt update
sudo apt install -y curl
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt install -y nodejs
node --version
```

Es sollte `v22.…` oder höher erscheinen. Ist die Zahl kleiner als 22, schick mir die Ausgabe.

*Alternative ohne Systemänderung:* Auf nodejs.org die «Linux Binaries (x64)» herunterladen, in deinen Home-Ordner entpacken und den Ordner `bin` in den `PATH` aufnehmen. Wenn du das lieber willst, sag Bescheid, dann schreibe ich die Befehle dazu.

---

## 2. Android Studio installieren

Auf Linux Mint ist «Snap» meist abgeschaltet, deshalb nimm die offizielle Datei:

1. Auf **developer.android.com/studio** die **Linux-Version** (`android-studio-….tar.gz`) herunterladen. Sie landet im Ordner `Downloads`.
2. Im Terminal entpacken (legt `/usr/local/android-studio` an):
   ```
   sudo tar -xzf ~/Downloads/android-studio-*-linux.tar.gz -C /usr/local/
   ```
3. Starten:
   ```
   /usr/local/android-studio/bin/studio.sh
   ```
4. Der **Einrichtungsassistent** erscheint: «Standard» wählen, Lizenzen annehmen, warten, bis das Android SDK geladen ist (10–30 Minuten). Das SDK landet in `~/Android/Sdk`.
5. Optional, damit du es danach im Menü findest: In Android Studio **Tools → Create Desktop Entry**.
6. Java brauchst du nicht zu installieren, Android Studio bringt es mit.

**Falls Android Studio nicht startet** oder später Programme aus dem SDK mit einer Meldung zu fehlenden Bibliotheken (`libs`) scheitern: Auf der offiziellen Seite developer.android.com/studio/install im Abschnitt **Linux** stehen die dafür nötigen Pakete. Schick mir bitte die Fehlermeldung, dann sage ich dir den passenden Befehl für deine Mint-Version.

---

## 3. Projekt vorbereiten

1. Entpacke `orgapi-android-projekt.zip` in deinen Home-Ordner, z. B. nach `~/orgapi-android`. Am einfachsten im Dateimanager: Rechtsklick → «Hier entpacken».
2. Terminal in diesem Ordner öffnen (Rechtsklick → «Im Terminal öffnen») oder:
   ```
   cd ~/orgapi-android
   ```
3. Ausführen:
   ```
   node prepare.mjs
   ```
   Das lädt Bausteine aus dem Internet (einige Minuten) und endet mit «Fertig. Nächster Schritt: npx cap open android». Rote Zeilen mit «npm WARN» sind meist harmlos. Bei «ERROR» oder «FEHLER»: Meldung kopieren und schicken.
4. Das Skript nimmt die Voreinstellungen (App-ID `io.github.raster_werk.orgapi`, Adresse `https://raster-werk.github.io/orgapi/orgapi.html`).

---

## 4. In Android Studio öffnen

1. Android Studio starten (siehe Schritt 2.3) → **Open** → den Ordner `~/orgapi-android/android` wählen. (Der Befehl `npx cap open android` findet Android Studio auf Linux nur am Standardort. Wenn er nichts öffnet, ist das nicht schlimm, öffne den Ordner einfach von Hand.)
2. Beim ersten Öffnen läuft unten rechts der **«Gradle Sync»**. **Warten**, bis er fertig ist (beim ersten Mal 5–15 Minuten, braucht Internet).
3. Schlägt Android Studio ein **Update** vor («Update Android Gradle Plugin» o. ä.), **nicht annehmen** («Remind me later»).

---

## 5. Handy vorbereiten (mit Linux-Zusatz)

1. **Entwickleroptionen freischalten:** Einstellungen → «Über das Telefon» → **Build-Nummer** 7× antippen.
2. Einstellungen → **Entwickleroptionen** → **USB-Debugging** einschalten.
3. **Nur auf Linux nötig:** Damit dein Benutzer das Handy ansprechen darf, im Terminal:
   ```
   sudo apt install -y android-sdk-platform-tools-common
   sudo usermod -aG plugdev $USER
   ```
   Danach **einmal ab- und wieder anmelden** (oder den Computer neu starten).
4. Handy per **USB-Datenkabel** verbinden. Am Handy bei «USB-Debugging zulassen?» auf **Zulassen** tippen. USB-Modus: «Dateiübertragung».
5. In Android Studio erscheint das Handy oben in der Geräteauswahl. Erscheint es nicht: Kabel wechseln, USB-Modus prüfen. Zum Prüfen im Terminal:
   ```
   ~/Android/Sdk/platform-tools/adb devices
   ```
   Dort sollte dein Handy ohne «unauthorized» auftauchen.

*Emulator statt Handy:* Auf Linux braucht er Hardware-Beschleunigung (KVM). Für den Kalender-Abgleich ist ein echtes Handy aussagekräftiger, deshalb würde ich damit anfangen.

---

## 6. App starten und Kalender prüfen

Genau wie in der allgemeinen Anleitung: In Android Studio das Handy wählen, auf den **grünen Pfeil (Run)** drücken. In Orgapi: ⋮ → **«Handy-Kalender abgleichen …»** → «Zugriff erlauben» → Android fragt nach dem Kalender → «Zulassen» → Kalender wählen → «In Handy-Kalender schreiben».

---

## Häufige Linux-Probleme

| Problem | Was du tust |
|---|---|
| `node: command not found` | Terminal schliessen und neu öffnen. Sonst die Schritte aus 1 wiederholen. |
| `node --version` zeigt unter v22 | Die NodeSource-Zeilen aus Schritt 1 nochmals ausführen und mir die Ausgabe schicken. |
| `permission denied` bei `studio.sh` | `sudo chmod +x /usr/local/android-studio/bin/studio.sh` |
| Handy erscheint nicht | Gruppe `plugdev` gesetzt und neu angemeldet? Kabel/USB-Modus prüfen, `adb devices` ansehen. |
| `unauthorized` bei `adb devices` | Am Handy die USB-Debugging-Abfrage bestätigen. Hilft das nicht: Handy abziehen und in den Entwickleroptionen «USB-Debugging-Autorisierungen widerrufen», dann neu verbinden. |
| Gradle Sync schlägt fehl | Meldung kopieren und schicken. Oft hilft: Android Studio → Settings → Build Tools → Gradle → Gradle JDK = mitgeliefertes («jbr»/«Embedded JDK»). |
| Anderes | Meldung im Wortlaut schicken. |
