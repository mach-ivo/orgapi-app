// Bereitet das Android-Projekt vor: Web-Dateien kopieren, Adresse eintragen, Berechtigungen setzen, Capacitor abgleichen.
// Aufruf:  node prepare.mjs            (nimmt die Voreinstellungen unten)
// oder:    node prepare.mjs --id io.github.raster_werk.orgapi --url https://raster-werk.github.io/orgapi/orgapi.html
// Zum Ausprobieren ohne Installation: zusätzlich --dry anhängen.
// Voreinstellungen (hier ändern, falls Repository oder Name anders heissen):
const DEFAULT_ID = 'io.github.raster_werk.orgapi';
const DEFAULT_URL = 'https://raster-werk.github.io/orgapi/orgapi.html';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const opt = (n) => { const i = args.indexOf('--' + n); return i >= 0 ? (args[i + 1] || '') : null; };
const dry = args.includes('--dry');
const appId = opt('id') || DEFAULT_ID, publicUrl = opt('url') !== null ? opt('url') : DEFAULT_URL;

const fail = (m) => { console.error('\nFEHLER: ' + m + '\n'); process.exit(1); };
if (!appId || !/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(appId)) fail('Bitte eine App-ID angeben, z. B.  --id ch.deinname.orgapi  (nur Kleinbuchstaben, Ziffern, Punkte; mindestens zwei Teile). Sie lässt sich später nicht mehr ändern.');
if (publicUrl && !/^https:\/\/[^\s'"\\]+$/.test(publicUrl)) fail('--url muss mit https:// beginnen und darf keine Leerzeichen oder Anführungszeichen enthalten.');

const run = (cmd, a) => {
  console.log('\n> ' + cmd + ' ' + a.join(' '));
  if (dry) return;
  const r = spawnSync(cmd, a, { cwd: here, stdio: 'inherit', shell: true });
  if (r.status !== 0) fail('Der Befehl "' + cmd + ' ' + a.join(' ') + '" ist fehlgeschlagen.');
};

// 1) Abhängigkeiten
if (!fs.existsSync(path.join(here, 'node_modules', '@capacitor', 'core'))) {
  run('npm', ['install', '@capacitor/core', '@capacitor/android', '@capacitor/filesystem', '@capacitor/share', '@ebarooni/capacitor-calendar']);
  run('npm', ['install', '--save-dev', '@capacitor/cli']);
}

// 2) Konfiguration
const config = { appId, appName: 'Orgapi', webDir: 'www', server: { androidScheme: 'https' } };
fs.writeFileSync(path.join(here, 'capacitor.config.json'), JSON.stringify(config, null, 2) + '\n');
console.log('capacitor.config.json geschrieben (App-ID ' + appId + ')');

// 3) Web-Dateien nach www kopieren
const www = path.join(here, 'www');
fs.rmSync(www, { recursive: true, force: true });
fs.cpSync(path.join(here, 'web'), www, { recursive: true });
const html = path.join(www, 'orgapi.html');
let src = fs.readFileSync(html, 'utf8');
if (publicUrl) {
  if (!/const PUBLIC_URL = '[^']*';/.test(src)) fail("In orgapi.html wurde die Zeile 'const PUBLIC_URL = ...;' nicht gefunden.");
  src = src.replace(/const PUBLIC_URL = '[^']*';/, "const PUBLIC_URL = '" + publicUrl + "';");
  fs.writeFileSync(html, src);
  console.log('Öffentliche Adresse eingetragen: ' + publicUrl);
} else {
  console.log('Hinweis: ohne --url funktionieren Familien-Paket-Links und QR-Codes nur als Datei (siehe LIESMICH).');
}

// 4) Android-Projekt anlegen
if (!fs.existsSync(path.join(here, 'android'))) run('npx', ['cap', 'add', 'android']);

// 5) Berechtigungen im Manifest
const manifest = path.join(here, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifest)) {
  let m = fs.readFileSync(manifest, 'utf8');
  const need = [
    '<uses-permission android:name="android.permission.READ_CALENDAR" />',
    '<uses-permission android:name="android.permission.WRITE_CALENDAR" />',
    '<uses-permission android:name="android.permission.CAMERA" />',
    '<uses-feature android:name="android.hardware.camera" android:required="false" />'
  ];
  const add = need.filter((l) => !m.includes(l.match(/android:name="([^"]+)"/)[1]));
  if (add.length) {
    if (!m.includes('<application')) fail('Im Manifest wurde <application nicht gefunden.');
    m = m.replace('<application', add.map((l) => l).join('\n    ') + '\n\n    <application');
    fs.writeFileSync(manifest, m);
    console.log('Berechtigungen ergänzt: ' + add.length);
  } else console.log('Berechtigungen waren schon eingetragen.');
} else if (!dry) fail('AndroidManifest.xml nicht gefunden: ' + manifest);
else console.log('(Probelauf: Manifest übersprungen)');

// 6) Abgleich
run('npx', ['cap', 'sync', 'android']);
console.log('\nFertig. Nächster Schritt:  npx cap open android   (öffnet Android Studio)');
